var getQueryParam = function (p, d, u, h) {
	var p_gpv = function (k, u, h) {
		var pt = function (x, d, a) {
			var p_gvf = function (t, k) {
				var epa = function (x) {
					var rep = function (x, o, n) {
						var jn = function (a, d) {
							var x = '',
							i,
							j = a.length;
							if (a && j > 0) {
								x = a[0];
								if (j > 1) {
									if (a.join)
										x = a.join(d);
									else
										for (i = 1; i < j; i++)
											x += d + a[i]
								}
							}
							return x
						};

						var sp = function (x, d) {
							var a = new Array,
							i = 0,
							j;
							if (x) {
								if (x.split)
									a = x.split(d);
								else if (!d)
									for (i = 0; i < x.length; i++)
										a[a.length] = x.substring(i, i + 1);
								else
									while (i >= 0) {
										j = x.indexOf(d, i);
										a[a.length] = x.substring(i, j < 0 ? x.length : j);
										i = j;
										if (i >= 0)
											i += d.length
									}
							}
							return a
						};

						return jn(sp(x, o), n)
					};
                    
                    if (x) {
						x = '' + x;
						var em=0;
                        if(em.toPrecision)em=3;
                        else if(String.fromCharCode){
                            i=escape(String.fromCharCode(256)).toUpperCase();
                            em=(i=='%C4%80'?2:(i=='%U0100'?1:0))
                        }
                        return em == 3 ? decodeURIComponent(x) : unescape(rep(x, '+', ' '))
					}
					return x
				};

				if (t) {
					var i = t.indexOf('='),
					p = i < 0 ? t : t.substring(0, i),
					v = i < 0 ? 'True' : t.substring(i + 1);
					if (p.toLowerCase() == k.toLowerCase())
						return epa(v)
				}
				return ''
			};

			var t = x,
			z = 0,
			y,
			r;
			while (t) {
				y = t.indexOf(d);
				y = y < 0 ? t.length : y;
				t = t.substring(0, y);
				r = p_gvf(t, a);
				if (r)
					return r;
				z += y + d.length;
				t = x.substring(z, x.length);
				t = z < x.length ? t : ''
			}
			return ''
		};

		var v = '',
		q;
		j = h == 1 ? '#' : '?';
		i = u.indexOf(j);
		if (k && i > -1) {
			q = u.substring(i + 1);
			v = pt(q, '&', k)
		}
		return v
	};

	var v = '',
	i,
	j,
	t;
	d = d ? d : '';
	u = u ? u : (document.URL ? document.URL : window.location);
	if (u == 'f')
		u = window.top.location;
	while (p) {
		i = p.indexOf(',');
		i = i < 0 ? p.length : i;
		t = p_gpv(p.substring(0, i), u + '', h);
		if (t) {
			t = t.indexOf('#') > -1 ? t.substring(0, t.indexOf('#')) : t;
		}
		if (t)
			v += v ? d + t : t;
		p = p.substring(i == p.length ? i : i + 1)
	}
	return v
}
