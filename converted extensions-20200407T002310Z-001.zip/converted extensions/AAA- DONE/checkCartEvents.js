s.checkCartEvents = function (cookieName, days, reset) {
    /*descripiton:
    Run this plugin on the cart page and the order confirmation page. It
    will track cart add and remove events based on what is given on the
    cart page.
    params:
    cookieName: name of the cookie to store our current cart products in
    days: days to keep this cookie before expired
    reset: don't define or set to false to run the cart logic,
    set to true to reset the cookie (usually on a confirmation page)
    output:
    returns the new s.events
     */

    var q = function (name, value, seconds) {
        /*write cookie*/
        var d = new Date();
        if (seconds)
            d.setTime(d.getTime() + (seconds * 1000));
        document.cookie = name + "=" + value + ";path=/;domain=;expires=" + d.toGMTString();
    };
    var r = function (name) {
        /*read cookie*/
        var pairs = document.cookie.split(";");
        for (var i = 0; i < pairs.length; i++) {
            var pair = pairs[i].split("=");
            if (name == pair[0].trim())
                return unescape(pair[1]);
        }
        return "";
    };
    var e = function (v) {
        /*isEmpty*/
        if (typeof v == "string" && v)
            return false;
        else if (typeof v == "number" && v)
            return false;
        else {
            for (var p in v) {
                if (v.hasOwnProperty(p)) {
                    return false;
                }
            }
        }
        return true;
    };
    var fireAdd = function (arr) {
        /*fire the cart add event*/
        s.events = !s.events ? "scAdd" : s.events + ",scAdd";
        q(cookieName, arr.join(","), days * 60 * 60);
    };
    var fireRemove = function (arr) {
        /*fire the cart remove event*/
        s.events = !s.events ? "scRemove" : s.events + ",scRemove";
        q(cookieName, arr.join(","), days * 60 * 60);
    };

    /*** begin logic on load of cart page ***/
    if (!reset) {
        //create array of current product ids
        var ids = [];
        var items = s.products.split(',');
        for (var i = 0; i < items.length; i++) {
            var params = items[i].split(';');
            ids.push(params[1]);
        }

        var cookie = r(cookieName);
        if (ids.length > 0) { // products in cart, let's investigate
            if (e(cookie)) {
                fireAdd(ids); // nothing in cookie, fire add and create it
            } else { // there are some cookie items, let's compare
                var cArr = cookie.split(",");
                if (ids.length > cArr.length) { // cart item length more than cookie, fire add
                    fireAdd(ids);
                } else if (ids.length == cArr.length) { // same amount of items. need to check ids and see if different
                    var n = 0;
                    for (i = 0; i < ids.length; i++) {
                        for (j = 0; j < cArr.length; j++) {
                            if (ids[j] == cArr[i])
                                n++;
                        }
                    }
                    if (n != ids.length) { // ids are different, meaning a new product in cart. fire add and remove
                        fireAdd(ids);
                        fireRemove(ids);
                    } else {}
                    // ids are the same, do nothing
                } else { // cookie has more items (implying a remove) update it
                    fireRemove(ids);
                }
            }
        } else {
            if (!e(cookie)) { //cookie has values, but cart doesn't, so fire remove
                fireRemove(ids);
            }
        }
    }

    if (reset)
        q(cookieName, "", -1); //clear the cookie when needed (usually on a confirmation page)

    return s.events;
};
